import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { db } from "@/lib/firebase";
import { doc, getDoc, setDoc, collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { LogOut, Menu, X, Home, User, Users, CreditCard, Info, Wallet, Shield, Pickaxe, Zap } from "lucide-react";
import MiningDashboard from "@/components/MiningDashboard";
import UpgradePage from "@/components/UpgradePage";
import PoliciesPage from "@/components/PoliciesPage";

interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  createdAt: any;
  invitation?: string;
  referralCode?: string;
  referredBy?: string;
  package?: string;
  packagePrice?: number;
}

interface Profile {
  userId: string;
  firstName: string;
  lastName: string;
  dob: string;
  gender: string;
  phone: string;
  address: string;
  createdAt: any;
}

// F2 Referrals Component
function F2Referrals({ userId, onTotalChange }: { userId: string; onTotalChange?: (total: number) => void }) {
  const [f2Referrals, setF2Referrals] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchF2Referrals = async () => {
      try {
        // Step 1: Get direct referrals (F1)
        const q1 = query(collection(db, "users"), where("referredBy", "==", userId));
        const snap1 = await getDocs(q1);

        let f2List: User[] = [];

        // Step 2: For each F1 user, get their referrals (F2 - indirect referrals)
        for (let doc1 of snap1.docs) {
          const userF1Id = doc1.id;

          const q2 = query(collection(db, "users"), where("referredBy", "==", userF1Id));
          const snap2 = await getDocs(q2);

          snap2.docs.forEach(doc => {
            const userData = doc.data() as User;
            f2List.push(userData);
          });
        }

        setF2Referrals(f2List);
        
        // Calculate total F2 commission
        const total = f2List.reduce((sum, r) => sum + (0.025 * (r.packagePrice || 100)), 0);
        onTotalChange?.(total);
      } catch (error) {
        console.error("Error fetching F2 referrals:", error);
        onTotalChange?.(0);
      } finally {
        setLoading(false);
      }
    };

    fetchF2Referrals();
  }, [userId, onTotalChange]);

  if (loading) {
    return <p className="text-muted-foreground">Loading indirect referrals...</p>;
  }

  if (f2Referrals.length === 0) {
    return <p className="text-muted-foreground mb-4">No indirect referrals yet.</p>;
  }

  return (
    <div className="space-y-2 mb-4">
      {f2Referrals.map((referral, index) => (
        <div
          key={index}
          className="flex justify-between items-center p-3 border rounded-lg bg-blue-50 dark:bg-blue-900/20"
          data-testid={`f2-referral-${index}`}
        >
          <div>
            <p className="font-medium">@{referral.username}</p>
            <p className="text-sm text-muted-foreground">
              Joined {new Date(referral.createdAt?.toDate?.() || referral.createdAt).toLocaleDateString()}
            </p>
            <p className="text-xs text-muted-foreground">
              Referred by: @{referral.referredBy}
            </p>
          </div>
          <div className="text-blue-600 font-bold">
            2.5% ({(0.025 * (referral.packagePrice || 100)).toFixed(2)} USDT)
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [referrals, setReferrals] = useState<User[]>([]);
  const [f2Total, setF2Total] = useState(0);
  const [referralData, setReferralData] = useState<{
    f1Commission: number;
    f2Commission: number;
    totalCommission: number;
    referredUsers: string[];
  } | null>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [pallBalance, setPallBalance] = useState(0);
  const [usdtBalance, setUsdtBalance] = useState(0);
  const [miningStatus, setMiningStatus] = useState(false);
  const [currentPackage, setCurrentPackage] = useState<string>("Free");
  const [miningSpeed, setMiningSpeed] = useState<number>(1);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState("HOME");
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    dob: "",
    gender: "",
    phone: "",
    address: "",
  });
  const [, navigate] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
      navigate("/signin");
      return;
    }

    const fetchData = async () => {
      try {
        // Fetch user data
        const userDoc = await getDoc(doc(db, "users", userId));
        if (userDoc.exists()) {
          setUser(userDoc.data() as User);
        } else {
          localStorage.removeItem("userId");
          navigate("/signin");
          return;
        }

        // Fetch profile data
        const profileDoc = await getDoc(doc(db, "profiles", userId));
        if (profileDoc.exists()) {
          setProfile(profileDoc.data() as Profile);
        }

        // Fetch referrals (people referred by this user)
        const q = query(
          collection(db, "users"),
          where("referredBy", "==", userDoc.data()?.username)
        );
        const referralSnap = await getDocs(q);
        const referralList = referralSnap.docs.map(doc => doc.data() as User);
        setReferrals(referralList);

        // Fetch mining data
        try {
          const walletSnap = await getDoc(doc(db, "wallets", userId));
          if (walletSnap.exists()) {
            const walletData = walletSnap.data();
            setPallBalance(walletData.pallBalance || 0);
            setUsdtBalance(walletData.usdtBalance || 0);
            setMiningStatus(walletData.miningActive || false);
            setCurrentPackage(walletData.currentPackage || "Free");
            setMiningSpeed(walletData.miningSpeed || 1);
          }
        } catch (error) {
          console.error("Error fetching mining data:", error);
        }

        // Fetch referral data
        try {
          const referralSnap = await getDoc(doc(db, "referrals", userId));
          if (referralSnap.exists()) {
            const refData = referralSnap.data();
            setReferralData({
              f1Commission: refData.f1Commission || 0,
              f2Commission: refData.f2Commission || 0,
              totalCommission: refData.totalCommission || 0,
              referredUsers: refData.referredUsers || []
            });
          } else {
            // Initialize referral document if it doesn't exist
            await setDoc(doc(db, "referrals", userId), {
              referredUsers: [],
              f1Commission: 0,
              f2Commission: 0,
              totalCommission: 0
            });
            setReferralData({
              f1Commission: 0,
              f2Commission: 0,
              totalCommission: 0,
              referredUsers: []
            });
          }
        } catch (error) {
          console.error("Error fetching referral data:", error);
        }

        // Fetch transaction history
        try {
          const transactionQuery = query(
            collection(db, "transactions"),
            where("userId", "==", userId),
            orderBy("createdAt", "desc")
          );
          const transactionSnap = await getDocs(transactionQuery);
          const transactionList = transactionSnap.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          }));
          setTransactions(transactionList);
        } catch (error) {
          console.error("Error fetching transactions:", error);
        }

      } catch (error) {
        console.error("Error fetching data:", error);
        localStorage.removeItem("userId");
        navigate("/signin");
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const saveProfile = async () => {
    if (profile) {
      toast({
        title: "Profile already exists",
        description: "Profile already filled, cannot edit again!",
        variant: "destructive",
      });
      return;
    }

    if (!user) return;

    try {
      await setDoc(doc(db, "profiles", user.id), {
        ...form,
        userId: user.id,
        createdAt: new Date(),
      });
      setProfile({ ...form, userId: user.id, createdAt: new Date() });
      toast({
        title: "Success",
        description: "Profile saved successfully!",
      });
    } catch (error) {
      console.error("Error saving profile:", error);
      toast({
        title: "Error",
        description: "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("userId");
    toast({
      title: "Signed out",
      description: "You have been signed out successfully.",
    });
    navigate("/signin");
  };

  const formatDate = (timestamp: any) => {
    if (!timestamp) return "Unknown";
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    } catch {
      return "Unknown";
    }
  };

  // Commission Totals
  const totalF1 = referralData?.f1Commission || 0;
  const totalF2 = referralData?.f2Commission || 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top Bar */}
      <div className="flex justify-between items-center bg-green-600 text-white p-4 shadow-lg">
        <div className="flex items-center space-x-3">
          <img src="/src/assets/app-icon.png" alt="Pall Network" className="w-8 h-8 rounded-full" />
          <h1 className="text-xl font-bold">Pall Network</h1>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="text-white hover:bg-green-700"
          data-testid="button-menu"
        >
          <Menu className="w-6 h-6" />
        </Button>
      </div>

      {/* Sidebar */}
      {sidebarOpen && (
        <div className="fixed top-0 right-0 h-full w-72 bg-white dark:bg-gray-900 shadow-lg z-50 border-l">
          <div className="p-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">Menu</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(false)}
                data-testid="button-close-sidebar"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <nav className="space-y-2">
              <Button
                variant={currentPage === "HOME" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("HOME"); setSidebarOpen(false); }}
                data-testid="nav-home"
              >
                <Home className="w-4 h-4 mr-3" />
                HOME
              </Button>
              <Button
                variant={currentPage === "PROFILE" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("PROFILE"); setSidebarOpen(false); }}
                data-testid="nav-profile"
              >
                <User className="w-4 h-4 mr-3" />
                PROFILE
              </Button>
              <Button
                variant={currentPage === "REFERRAL" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("REFERRAL"); setSidebarOpen(false); }}
                data-testid="nav-referral"
              >
                <Users className="w-4 h-4 mr-3" />
                REFERRAL TEAM
              </Button>
              <Button
                variant={currentPage === "WALLET" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("WALLET"); setSidebarOpen(false); }}
                data-testid="nav-wallet"
              >
                <Wallet className="w-4 h-4 mr-3" />
                WALLET
              </Button>
              <Button
                variant={currentPage === "MINING" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("MINING"); setSidebarOpen(false); }}
                data-testid="nav-mining"
              >
                <Pickaxe className="w-4 h-4 mr-3" />
                MINING
              </Button>
              <Button
                variant={currentPage === "UPGRADE" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("UPGRADE"); setSidebarOpen(false); }}
                data-testid="nav-upgrade"
              >
                <Zap className="w-4 h-4 mr-3" />
                UPGRADE
              </Button>
              <Button
                variant={currentPage === "KYC" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("KYC"); setSidebarOpen(false); }}
                data-testid="nav-kyc"
              >
                <Shield className="w-4 h-4 mr-3" />
                KYC VERIFICATION
              </Button>
              <Button
                variant={currentPage === "ABOUT" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => { setCurrentPage("ABOUT"); setSidebarOpen(false); }}
                data-testid="nav-about"
              >
                <Info className="w-4 h-4 mr-3" />
                POLICIES
              </Button>
            </nav>
            <div className="mt-8 pt-8 border-t">
              <Button
                variant="destructive"
                onClick={handleLogout}
                className="w-full"
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}

      {/* Main Content */}
      <div className="flex-1 p-6">
        <div className="container mx-auto max-w-4xl">
          {/* HOME Page */}
          {currentPage === "HOME" && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-2">Welcome to Pall Network Dashboard! 🚀</h2>
                <p className="text-muted-foreground mb-6">
                  A decentralized crypto mining and commerce platform
                </p>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <h3 className="text-xl font-bold text-blue-600">{pallBalance.toFixed(4)}</h3>
                    <p className="text-sm text-muted-foreground">PALL Balance</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <h3 className="text-xl font-bold text-green-600">{referrals.length}</h3>
                    <p className="text-sm text-muted-foreground">Total Referrals</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <h3 className="text-xl font-bold text-purple-600">{(totalF1 + totalF2).toFixed(2)}</h3>
                    <p className="text-sm text-muted-foreground">USDT Earnings</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <h3 className={`text-xl font-bold ${miningStatus ? 'text-green-600' : 'text-gray-500'}`}>
                      {miningStatus ? '⚡ Active' : '⛏ Idle'}
                    </h3>
                    <p className="text-sm text-muted-foreground">Mining Status</p>
                  </CardContent>
                </Card>
              </div>

              {/* Current Mining Package */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold mb-2">Current Mining Package</h3>
                      <p className="text-2xl font-bold text-blue-600">{currentPackage}</p>
                      <p className="text-sm text-muted-foreground">
                        Mining Speed: {miningSpeed}X {currentPackage === "Free" ? "(0.01 PALL/sec)" : `(${(0.01 * miningSpeed).toFixed(3)} PALL/sec)`}
                      </p>
                    </div>
                    <Button
                      onClick={() => setCurrentPage("UPGRADE")}
                      className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                      data-testid="button-upgrade-mining"
                    >
                      ⚡ Upgrade Mining
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Referral Code */}
              {user.referralCode && (
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4">Your Referral Code</h3>
                    <div className="flex items-center justify-between bg-muted p-4 rounded-lg">
                      <code className="font-mono text-lg">{user.referralCode}</code>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          navigator.clipboard.writeText(user.referralCode || "");
                          toast({
                            title: "Copied!",
                            description: "Referral code copied to clipboard",
                          });
                        }}
                        data-testid="button-copy-code"
                      >
                        Copy
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Share this code with friends to earn commissions from referrals
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* PROFILE Page */}
          {currentPage === "PROFILE" && (
            <Card>
              <CardHeader>
                <h2 className="text-2xl font-bold">Profile Information</h2>
              </CardHeader>
              <CardContent>
                {profile ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <strong>First Name:</strong> {profile.firstName}
                      </div>
                      <div>
                        <strong>Last Name:</strong> {profile.lastName}
                      </div>
                      <div>
                        <strong>Date of Birth:</strong> {profile.dob}
                      </div>
                      <div>
                        <strong>Gender:</strong> {profile.gender}
                      </div>
                      <div>
                        <strong>Phone:</strong> {profile.phone}
                      </div>
                      <div>
                        <strong>Address:</strong> {profile.address}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          name="firstName"
                          value={form.firstName}
                          onChange={handleFormChange}
                          data-testid="input-first-name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          name="lastName"
                          value={form.lastName}
                          onChange={handleFormChange}
                          data-testid="input-last-name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="dob">Date of Birth</Label>
                        <Input
                          id="dob"
                          name="dob"
                          type="date"
                          value={form.dob}
                          onChange={handleFormChange}
                          data-testid="input-dob"
                        />
                      </div>
                      <div>
                        <Label htmlFor="gender">Gender</Label>
                        <select
                          id="gender"
                          name="gender"
                          value={form.gender}
                          onChange={handleFormChange}
                          className="w-full p-2 border border-input rounded-md bg-background"
                          data-testid="select-gender"
                        >
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                          <option value="Prefer not to say">Prefer not to say</option>
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={form.phone}
                          onChange={handleFormChange}
                          data-testid="input-phone"
                        />
                      </div>
                      <div>
                        <Label htmlFor="address">Address</Label>
                        <Input
                          id="address"
                          name="address"
                          value={form.address}
                          onChange={handleFormChange}
                          data-testid="input-address"
                        />
                      </div>
                    </div>
                    <Button
                      onClick={saveProfile}
                      className="w-full bg-green-600 hover:bg-green-700"
                      data-testid="button-save-profile"
                    >
                      Save Profile
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* REFERRAL Page */}
          {currentPage === "REFERRAL" && (
            <Card>
              <CardHeader>
                <h2 className="text-2xl font-bold">Referral Team</h2>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* F1 Direct Referrals */}
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-green-600">
                    Direct Referrals (F1) – 5% Commission
                  </h3>
                  {referrals.length === 0 ? (
                    <p className="text-muted-foreground mb-4">No direct referrals yet.</p>
                  ) : (
                    <div className="space-y-2 mb-4">
                      {referrals.map((referral, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center p-3 border rounded-lg bg-green-50 dark:bg-green-900/20"
                          data-testid={`f1-referral-${index}`}
                        >
                          <div>
                            <p className="font-medium">@{referral.username}</p>
                            <p className="text-sm text-muted-foreground">
                              Joined {formatDate(referral.createdAt)}
                            </p>
                          </div>
                          <div className="text-green-600 font-bold">
                            5% ({(0.05 * (referral.packagePrice || 100)).toFixed(2)} USDT)
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* F2 Indirect Referrals */}
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-blue-600">
                    Indirect Referrals (F2) – 2.5% Commission
                  </h3>
                  {user && <F2Referrals userId={user.username} onTotalChange={setF2Total} />}
                </div>

                {/* Commission Summary */}
                <div className="mt-6 p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold mb-2">Commission Summary</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">F1 Total:</span>
                      <span className="ml-2 font-bold text-green-600">
                        {totalF1.toFixed(2)} USDT
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">F2 Total:</span>
                      <span className="ml-2 font-bold text-blue-600" data-testid="f2-total">
                        {totalF2.toFixed(2)} USDT
                      </span>
                    </div>
                  </div>
                  <p className="mt-4 font-bold">
                    Total Referral Commission: {(totalF1 + totalF2).toFixed(2)} USDT
                  </p>
                </div>

                {referrals.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      No referrals yet. Share your referral code to start earning!
                    </p>
                    {user?.referralCode && (
                      <div className="bg-muted p-4 rounded-lg inline-block">
                        <code className="font-mono">{user.referralCode}</code>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* WALLET Page */}
          {currentPage === "WALLET" && (
            <div className="bg-white dark:bg-card p-6 rounded shadow-md max-w-md mx-auto">
              <h2 className="text-2xl font-bold mb-4">💳 Wallet</h2>
              
              {/* Balance Display */}
              <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg">
                <p className="text-lg mb-2">💰 <strong>PALL Balance:</strong> {pallBalance.toFixed(4)} PALL</p>
                <p className="text-lg mb-2">💵 <strong>USDT Balance:</strong> {(totalF1 + totalF2).toFixed(2)} USDT</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Referral Earnings: F1 ({totalF1.toFixed(2)}) + F2 ({totalF2.toFixed(2)})</p>
              </div>

              {/* Wallet Connection Status */}
              <div className="mb-4 p-3 border rounded-lg">
                {typeof window !== 'undefined' && window.ethereum ? (
                  <div className="text-center">
                    <div className="text-green-600 dark:text-green-400 mb-2">✅ Web3 Wallet Detected</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {window.ethereum.isMetaMask ? "MetaMask" : 
                       window.ethereum.isTrust ? "Trust Wallet" : 
                       window.ethereum.isCoinbaseWallet ? "Coinbase Wallet" : "Web3 Wallet"} is installed
                    </p>
                    <Button 
                      className="mt-2 w-full bg-blue-500 hover:bg-blue-600"
                      onClick={() => setCurrentPage("UPGRADE")}
                    >
                      Connect & Upgrade Package
                    </Button>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="text-yellow-600 dark:text-yellow-400 mb-2">⚠️ No Web3 Wallet Found</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      Install a Web3 wallet to enable USDT transactions
                    </p>
                    <div className="space-y-2">
                      <a
                        href="https://metamask.io/download/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full bg-orange-500 hover:bg-orange-600 text-white p-2 rounded text-center transition-colors"
                      >
                        📦 Install MetaMask
                      </a>
                      <a
                        href="https://trustwallet.com/download"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full bg-blue-500 hover:bg-blue-600 text-white p-2 rounded text-center transition-colors"
                      >
                        📱 Install Trust Wallet
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* Transaction Info */}
              <div className="text-center text-sm text-gray-600 dark:text-gray-400">
                <p>💡 <strong>Note:</strong> This is a cloud mining simulation platform.</p>
                <p>USDT transactions are processed via blockchain wallets.</p>
              </div>
            </div>
          )}

          {/* MINING Page */}
          {currentPage === "MINING" && (
            <div>
              {user && <MiningDashboard userId={user.id} />}
            </div>
          )}

          {/* UPGRADE Page */}
          {currentPage === "UPGRADE" && (
            <div>
              {user && <UpgradePage userId={user.id} />}
            </div>
          )}

          {/* KYC Page */}
          {currentPage === "KYC" && (
            <Card>
              <CardHeader>
                <h2 className="text-2xl font-bold">Transaction History</h2>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <div className="text-center py-12">
                    <CreditCard className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No Transactions</h3>
                    <p className="text-muted-foreground">
                      Your package upgrades will appear here
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {transactions.map((tx) => (
                      <div key={tx.id} className="border rounded-lg p-4 flex justify-between items-center">
                        <div>
                          <h3 className="font-semibold">{tx.package} Package</h3>
                          <p className="text-sm text-muted-foreground">
                            {tx.speed}X Mining Speed • {tx.network}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(tx.createdAt.toDate ? tx.createdAt.toDate() : tx.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600">{tx.amount} USDT</p>
                          <p className="text-xs text-muted-foreground capitalize">{tx.status}</p>
                          <a 
                            href={`https://bscscan.com/tx/${tx.txHash}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:underline"
                            data-testid={`link-tx-${tx.id}`}
                          >
                            View on BscScan
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* ABOUT Page */}
          {currentPage === "ABOUT" && (
            <PoliciesPage onBack={() => setCurrentPage("HOME")} />
          )}
        </div>
      </div>
    </div>
  );
}
